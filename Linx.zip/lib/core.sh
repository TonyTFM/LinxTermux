#!/usr/bin/env bash

BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

source "$BASE/lib/menu.sh"
source "$BASE/lib/terminal.sh"
source "$BASE/lib/vm.sh"
source "$BASE/lib/os.sh"
source "$BASE/lib/ai.sh"
source "$BASE/lib/packages.sh"
source "$BASE/lib/settings.sh"
source "$BASE/lib/about.sh"
source "$BASE/lib/router.sh"
source "$BASE/lib/vm_engine.sh"
source "$BASE/lib/vm.sh"
source "$BASE/lib/os_engine.sh"
source "$BASE/lib/terminal_engine.sh"
