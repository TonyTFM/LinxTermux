#!/usr/bin/env bash

show_menu() {

    clear

    echo "========================="
    echo "        LINX 2.0"
    echo "========================="
    echo
    echo "1) Terminal"
    echo "2) Virtual Machines"
    echo "3) Operating Systems"
    echo "4) AI"
    echo "5) Packages"
    echo "6) Settings"
    echo "7) About"
    echo
    echo "0) Exit"
    echo

    read -rp "Select: " choice

    case "$choice" in
        1) echo "Terminal";;
        2) echo "Virtual Machines";;
        3) echo "Operating Systems";;
        4) echo "Artificial Intelligence";;
        5) echo "Packages";;
        6) echo "Settings";;
        7) echo "Linx 2.0";;
        0) exit;;
        *) echo "Invalid option";;
    esac
}
