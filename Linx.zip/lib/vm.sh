#!/usr/bin/env bash

vm_router() {

    case "$1" in

start)
    if [ -z "$2" ]; then
        vm_start_ux
    else
        vm_start "$2" "$3"
    fi
    ;;
stop)
    vm_stop "$2"
    ;;

status)
    vm_status "$2"
    ;;
        list)
            vm_list
            ;;
ps)
    vm_ps
    ;;

        *)
            echo "Usage:"
            echo "  linx vm list"
            echo "  linx vm start <name>"
            ;;
    esac
}
