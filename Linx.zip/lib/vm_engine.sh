#!/usr/bin/env bash

VM_DIR="$BASE/vms"

vm_list() {

    echo
    echo "Available Virtual Machines"
    echo "=========================="
    echo

    for file in "$VM_DIR"/*.yaml; do
        [ -f "$file" ] || continue
        NAME=$(yq '.name' "$file")
        echo "- $NAME"
    done

    echo
}
vm_start() {

    local vm="$1"
    local mode="$2"
    local file="$VM_DIR/$vm.yaml"

    if [ ! -f "$file" ]; then
        echo "VM not found: $vm"
        return 1
    fi

    NAME=$(yq '.name' "$file")
    RAM=$(yq '.memory' "$file")
    CPUS=$(yq '.cpus' "$file")
    DISK=$(yq '.disk' "$file")
    ISO=$(yq '.iso' "$file")
    MACHINE=$(yq '.machine' "$file")

    echo "Starting VM: $NAME"

    if [[ "$mode" == "--bg" ]]; then

        qemu-system-x86_64 \
            -name "$NAME" \
            -m "$RAM" \
            -smp "$CPUS" \
            -machine "$MACHINE" \
            -enable-kvm \
            -cpu host \
            -drive file="$DISK",format=qcow2 \
            -cdrom "$ISO" \
            -boot d \
            -display none &

        pid=$!
        echo "$pid" > ~/.linx/vms/"$vm.pid"

        echo "VM running in background (PID $pid)"

    else

        qemu-system-x86_64 \
            -name "$NAME" \
            -m "$RAM" \
            -smp "$CPUS" \
            -machine "$MACHINE" \
            -enable-kvm \
            -cpu host \
            -drive file="$DISK",format=qcow2 \
            -cdrom "$ISO" \
            -boot d \
            -display gtk

    fi
}
vm_select_and_start() {

    echo
    echo "Select VM to start"
    echo "=================="
    echo

    local files=()
    local names=()

    i=1

    for file in "$VM_DIR"/*.yaml; do
        [ -f "$file" ] || continue

        name=$(yq '.name' "$file")

        files[$i]="$file"
        names[$i]="$name"

        echo "$i) $name"

        i=$((i+1))
    done

    echo
    read -rp "Select: " choice

    file="${files[$choice]}"

    if [ -z "$file" ]; then
        echo "Invalid selection"
        return 1
    fi

    vm_start "$(basename "$file" .yaml)"
}
vm_stop() {

    local vm="$1"
    local pidfile="$HOME/.linx/vms/$vm.pid"

    if [ ! -f "$pidfile" ]; then
        echo "VM not running: $vm"
        return 1
    fi

    PID=$(cat "$pidfile")

    kill "$PID" 2>/dev/null

    rm -f "$pidfile"

    echo "VM stopped: $vm"
}
vm_status() {

    local vm="$1"
    local pidfile="$HOME/.linx/vms/$vm.pid"

    if [ ! -f "$pidfile" ]; then
        echo "VM: $vm → STOPPED"
        return
    fi

    PID=$(cat "$pidfile")

    if ps -p "$PID" > /dev/null; then
        echo "VM: $vm → RUNNING (PID $PID)"
    else
        echo "VM: $vm → STOPPED (stale PID removed)"
        rm -f "$pidfile"
    fi
}
vm_ps() {

    echo
    echo "Running VMs"
    echo "==========="
    echo

    for file in "$VM_DIR"/*.yaml; do
        [ -f "$file" ] || continue

        vm=$(basename "$file" .yaml)
        pidfile="$HOME/.linx/vms/$vm.pid"

        if [ -f "$pidfile" ]; then
            pid=$(cat "$pidfile")

            if ps -p "$pid" > /dev/null; then
                status="RUNNING"
            else
                status="STOPPED (stale)"
                rm -f "$pidfile"
            fi
        else
            pid="0"
            status="STOPPED"
        fi

        printf "%-12s PID: %-6s %s\n" "$vm" "$pid" "$status"
    done

    echo
}
vm_start_ux() {

    echo
    echo "Select VM to start"
    echo "=================="
    echo

    local files=()
    local names=()

    i=1

    for file in "$VM_DIR"/*.yaml; do
        [ -f "$file" ] || continue

        name=$(yq '.name' "$file")

        files[$i]="$file"
        names[$i]="$name"

        echo "$i) $name"

        i=$((i+1))
    done

    echo
    read -rp "Select: " choice

    file="${files[$choice]}"

    if [ -z "$file" ]; then
        echo "Invalid selection"
        return 1
    fi

    vm=$(basename "$file" .yaml)

    echo
    read -rp "Start in background? (y/n): " bg

    if [[ "$bg" == "y" ]]; then
        vm_start "$vm" "--bg"
    else
        vm_start "$vm"
    fi
}
