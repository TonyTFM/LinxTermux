#!/usr/bin/env bash

terminal_start() {

    if [ -f ~/.linx_current_os ]; then
        os=$(cat ~/.linx_current_os)
        echo "Starting Linx Terminal for OS: $os"
    else
        echo "Starting default Linx Terminal"
    fi

    bash
}
