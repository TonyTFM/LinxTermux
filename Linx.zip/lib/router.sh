#!/usr/bin/env bash

router() {

    if [ $# -eq 0 ]; then
        show_menu
        return
    fi

    case "$1" in

        vm)
            vm_router "${@:2}"
            ;;

        os)
            os_router "${@:2}"
            ;;

        ai)
            ai_router "${@:2}"
            ;;

        terminal)
            terminal_router "${@:2}"
            ;;

        package)
            package_router "${@:2}"
            ;;
os)
    os_select
    ;;

terminal)
    terminal_start
    ;;

        *)
            echo "Unknown command: $1"
            ;;
    esac
}
