#!/usr/bin/env bash

OS_DIR="$BASE/os"

os_list() {

    echo
    echo "Available Operating Systems"
    echo "==========================="
    echo

    for dir in "$OS_DIR"/*; do
        [ -d "$dir" ] || continue

        name=$(yq '.name' "$dir/os.yaml")

        echo "- $name"
    done

    echo
}
os_select() {

    echo
    echo "Select OS"
    echo "========="
    echo

    local i=1
    local files=()

    for dir in "$OS_DIR"/*; do
        [ -d "$dir" ] || continue

        name=$(yq '.name' "$dir/os.yaml")

        files[$i]="$dir"
        echo "$i) $name"

        i=$((i+1))
    done

    read -rp "Select: " choice

    selected="${files[$choice]}"

    if [ -z "$selected" ]; then
        echo "Invalid selection"
        return 1
    fi

    echo "OS set to: $(yq '.name' "$selected/os.yaml")"
    echo "$selected" > ~/.linx_current_os
}
