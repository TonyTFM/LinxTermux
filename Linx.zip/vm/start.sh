#!/usr/bin/env bash

vm_start() {

    clear

    echo "========================="
    echo "      Start Virtual Machine"
    echo "========================="
    echo

    echo "1) Mint11Pro"
    echo "2) Alpine Linux"
    echo "3) Debian"
    echo "4) TinyCore"

    echo
    echo "0) Back"
    echo

    read -rp "Select: " vm

    case "$vm" in

        1)
            echo
            echo "Starting Mint11Pro..."
            ;;

        2)
            echo
            echo "Starting Alpine..."
            ;;

        3)
            echo
            echo "Starting Debian..."
            ;;

        4)
            echo
            echo "Starting TinyCore..."
            ;;

        0)
            return
            ;;

        *)
            echo "Invalid choice."
            ;;
    esac
}
